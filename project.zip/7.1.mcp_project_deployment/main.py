def main():
    print("Hello from 7-1-mcp-project-deployment!")


if __name__ == "__main__":
    main()
